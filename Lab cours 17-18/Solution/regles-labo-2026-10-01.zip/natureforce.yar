/*
   natureforce.yar — Règles YARA pour le labo Security Onion
   Échantillon : runner_ilove.exe (pcap MTA 2026-10-01)
   SHA256 : b789adce70c028a6d17be45ec34667aa95586350ee0c4057e75b138b1ad35061
*/
import "pe"

rule SnailLabs_RunnerIlove_Exact
{
    meta:
        description = "Correspondance exacte : runner_ilove.exe (indicateur, fragile)"
        author      = "SnailLabs"
        date        = "2026-11-24"
        hash        = "b789adce70c028a6d17be45ec34667aa95586350ee0c4057e75b138b1ad35061"

    condition:
        uint16(0) == 0x5A4D and filesize == 1646592
        and pe.imphash() == "b8a6f94f6ddbd0872ad3843af22d24d5"
}

rule SnailLabs_Faux_Service_Canonical
{
    meta:
        description = "Exécutable Windows non signé qui se présente comme un service de Canonical Ltd."
        author      = "SnailLabs"
        date        = "2026-11-24"

    condition:
        uint16(0) == 0x5A4D
        and pe.version_info["CompanyName"] == "Canonical Ltd."
        and pe.version_info["OriginalFilename"] == "service.exe"
        and pe.number_of_signatures == 0
}

rule SnailLabs_Chargeur_MinGW_Suspect
{
    meta:
        description = "Chargeur MinGW-w64 : grosse section .rdata, date de compilation dans le futur, API d'exécution en mémoire"
        author      = "SnailLabs"
        date        = "2026-11-24"

    strings:
        $mingw = "Mingw-w64 runtime failure:" ascii
        $api1  = "VirtualProtect" ascii
        $api2  = "VirtualAlloc" ascii
        $api3  = "CreateThread" ascii

    condition:
        uint16(0) == 0x5A4D
        and pe.is_64bit()
        and $mingw and all of ($api*)
        and pe.timestamp > 1893456000                 // compilé « après » le 1er janvier 2030
        and for any s in pe.sections : ( s.name == ".rdata" and s.raw_data_size > 1000000 )
}
